import java.util.ArrayList;

public class Student {
    int stdID;
    String name;
    int age;
    ArrayList<Course> courses = new ArrayList<>();
    double cgpa;

    public Student(int stdID, String name, int age, double cgpa) {
        this.stdID = stdID;
        this.name = name;
        this.age = age;
        this.courses = new ArrayList<>();
        this.cgpa = cgpa;
    }

    void addcourse(int id,String name){
        Course c = new Course(id,name);
        for (Course cc : courses) {
            if (cc.getCourseid() == id && cc.getCourseName().equalsIgnoreCase(name)) {
                System.out.println("Student Already Registered In That Course ID :/ ");
                return;
            }
        }
            courses.add(c);
        System.out.println("Course Added Successfully :)");

    }

    void removeCourse(int id){
        boolean found  = false;
        for (Course c : courses){
            if(c.getCourseid() == id){
                courses.remove(c);
                System.out.println("Courese Removed ");
                found = true;
                break;
            }
        }
        if (!found){
            System.out.println("Course Not Found With That ID or Name ");
        }
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    public int getStdID() {
        return stdID;
    }

    public void setStdID(int stdID) {
        this.stdID = stdID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


    public double getCgpa() {
        return cgpa;
    }

    public void setCgpa(double cgpa) {
        this.cgpa = cgpa;
    }

    public String displayrecord(){
        return "Student{" +
                " Student ID=" + stdID +
                ", Name=" + name + '\'' +
                ", Age=" + age +
                String.format(", CGPA= %.2f ", cgpa) +
                '}';
    }


}

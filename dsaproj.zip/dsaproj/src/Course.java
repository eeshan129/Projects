import java.util.ArrayList;

public class Course {
    int courseid;
    String courseName;
    Attendence attendence;



    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Attendence getAttendence() {
        return attendence;
    }

    public void setAttendence(Attendence attendence) {
        this.attendence = attendence;
    }

    public Course(int courseid, String courseName) {
        this.courseid = courseid;
        this.courseName = courseName;
        this.attendence = new Attendence();
    }




}

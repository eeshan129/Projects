import java.util.ArrayList;

public class AllCourses {
    int courseid;
    String courseName;

    public AllCourses(int courseid, String courseName) {
        this.courseid = courseid;
        this.courseName = courseName;
    }

    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }


    String display(){
        return
                "Course ID =" + courseid +
                ", Course Name='" + courseName + '\'';
    }
}

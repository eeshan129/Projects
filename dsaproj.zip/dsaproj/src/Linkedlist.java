import org.w3c.dom.Node;

import java.time.LocalDate;

public class Linkedlist {
    int stdid;
    LocalDate date;
    STATUS status;
    Linkedlist next;

    public Linkedlist(int stdid, STATUS status) {
        this.stdid = stdid;
        this.date = LocalDate.now();
        this.status = status;
        this.next = null;

    }

    public int getStdid() {
        return stdid;
    }

    public void setStdid(int stdid) {
        this.stdid = stdid;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public STATUS getStatus() {
        return status;
    }

    public void setStatus(STATUS status) {
        this.status = status;
    }
}

public class Attendence {
    Linkedlist head = null;

    void pushAttendence(int stdid, STATUS s){
        Linkedlist newnode = new Linkedlist(stdid,s);
        if (head == null) {
            head = newnode;
        }else {
            Linkedlist temp = head;
            newnode.next = temp;
            head = newnode;
        }
    }


    int popAttendence(){
        Linkedlist temp = head;
        if (head == null) {
            return 1;
        }
        head = head.next;
        return temp.getStdid();
    }

    int countpresent(){
        if (head == null) {
            return 0;
        }
        Linkedlist temp = head;
        int count =0 ;
        while (temp != null) {
            if (temp.getStatus() == STATUS.present) {
                count++;
            }
            temp = temp.next;
        }
        return count;
    }

    int countclasses(){
        if (head == null) {
            return 0;
        }
        Linkedlist temp = head;
        int count =0 ;
        while (temp != null) {
            count ++;
            temp = temp.next;
        }
        return count;
    }

    void PrintAttendence(){
        Linkedlist temp = head;
        System.out.println("      id       |       DATE     |       Status    ");
        while (temp != null) {
            System.out.println("       "+temp.getStdid() + "     |     "+ temp.getDate()+ "     |     " +  temp.getStatus());
            temp = temp.next;
        }
    }



}

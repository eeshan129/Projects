import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class studentManager {
    static  int id = 100;
    ArrayList<Student> student = new ArrayList<>();
    Scanner input = new Scanner(System.in);
    ArrayList<AllCourses> allcourses = new ArrayList<>();

    //Default data entered to test

    AllCourses c1 = new AllCourses(02,"Calculus");
    AllCourses c2 = new AllCourses(03,"Communication");
    AllCourses c3 = new AllCourses(04,"Assembly Lamguage");
    AllCourses c4 = new AllCourses(05,"Applied Physics");
    AllCourses c5 = new AllCourses(01,"DSA");

    Student s1 = new Student(id++,"Aliyan",21,3.11);
    Student s2 = new Student(id++,"Ali",21,2.51);
    Student s3 = new Student(id++,"Nadia",21,2.961);
    Student s4 = new Student(id++,"taha",21,2.10);
    Student s5 = new Student(id++,"Ayesha",21,3.55);

    Course cc1 = new Course(01,"DSA");
    Course cc2 = new Course(02,"Calculus");
    Course cc3 = new Course(03,"Communication");
    Course cc4 = new Course(04,"Assembly Lamguage");
    Course cc5 = new Course(05,"Applied Physics");

    public studentManager() {
        student.add(s1);
        student.add(s2);
        student.add(s3);
        student.add(s4);
        student.add(s5);
        allcourses.add(c1);
        allcourses.add(c2);
        allcourses.add(c3);
        allcourses.add(c4);
        allcourses.add(c5);
        s1.courses.add(cc1);
        s1.courses.add(cc2);
        s1.courses.add(cc3);
        s1.courses.add(cc4);
        s1.courses.add(cc5);
        s2.courses.add(cc1);
        s2.courses.add(cc2);
        s2.courses.add(cc3);
        s2.courses.add(cc4);
        s2.courses.add(cc5);
        s3.courses.add(cc1);
        s3.courses.add(cc2);
        s3.courses.add(cc3);
        s3.courses.add(cc4);
        s3.courses.add(cc5);
        s4.courses.add(cc1);
        s4.courses.add(cc2);
        s4.courses.add(cc3);
        s4.courses.add(cc4);
        s4.courses.add(cc5);
        s5.courses.add(cc1);
        s5.courses.add(cc2);
        s5.courses.add(cc3);
        s5.courses.add(cc4);
        s5.courses.add(cc5);

    }

    void viewAllCourses(){
        for (AllCourses a : allcourses){
            System.out.println(a.display());
        }
    }

    void addallCourse(int id, String name) {
        for (AllCourses c : allcourses) {
            if (c.getCourseid() == id) {
                System.out.println("Course with this ID already exists!");
                return;
            }
        }
        allcourses.add(new AllCourses(id, name));
        System.out.println("Course Added Successfully");
    }

    void removeMainCourse(int id){
        boolean found = false;
        for (AllCourses c : allcourses){
            if (c.getCourseid() == id ){
                allcourses.remove(c);
                System.out.println("Course "+ c.getCourseName() + " Removed");
                found = true;
                break;
            }
        }
        if (!found){
            System.out.println("Course Not In List");
        }
    }

    void removeCourseforstd(int stdid, int cid){
        Student ss = null;
        for (Student s : student) {
            if (s.getStdID() == stdid) {
                ss = s;
                break;
            }
        }
        if (ss == null) {
            System.out.println("Student Not Found");
        } else {
            ss.removeCourse(cid);
        }
    }

    void addCourseforStudent(int stdid, int cid, String name) {
        Student ss = null;
        for (Student s : student) {
            if (s.getStdID() == stdid) {
                ss = s;
                break;
            }
        }
        if (ss == null) {
            System.out.println("Student Not Found AddStudent first :)");
        } else {
            ss.addcourse(cid,name);
        }
    }

    void addStudent() {
        try {
            System.out.println("enter name: ");
            String name = input.next();

            System.out.println("enter Age: ");
            int age = input.nextInt();

            System.out.println("enter cgpa: ");
            float gpa = input.nextFloat();

            Student s = new Student(id++, name, age, gpa);
            student.add(s);
            System.out.println("Student Added Succcesfully :)");

        } catch (Exception e) {
            System.out.println("Invalid input! Please enter correct data.");
        }
    }

    void removeStudent(int id){
        try {
            for (Student s : student){
                if (s.stdID == id){
                    System.out.println(s.stdID +" " +  s.name + " removed");
                    student.remove(s);
                    return;
                }
            }
            System.out.println("student not in data :( ");
        } catch (Exception e) {
            System.out.println("Error removing student");
        }
    }

    //linear search
    void searchstdByname(String name){
        for (Student s : student){
            if (s.getName().equalsIgnoreCase(name)){
                System.out.println(s.displayrecord());
                return;
            }
        }
        System.out.println("no record with this name");
    }

    void viewAllstudent(){
        if(student.size() == 0){
            System.out.println("----------- All Students ---------- ");
            System.out.println("No Student In Record");
            return;
        }
        System.out.println("----------- All Students ---------- ");
        for (Student s : student){
            System.out.println(s.displayrecord());
        }
        }

        //cocktail sort
        void sortByCgpa() {
            int n = student.size();
            boolean swap = true;

            try {
                while (swap) {
                    swap = false;

                    for (int i = 0; i < n - 1; i++) {
                        if (student.get(i).getCgpa() < student.get(i + 1).getCgpa()) {
                            Student temp = student.get(i + 1);
                            student.set(i + 1, student.get(i));
                            student.set(i, temp);
                            swap = true;
                        }
                    }
                    for (int i = n - 1; i > 0; i--) {
                        if (student.get(i - 1).getCgpa() < student.get(i).getCgpa()) {
                            Student temp = student.get(i);
                            student.set(i, student.get(i - 1));
                            student.set(i - 1, temp);
                            swap = true;
                        }
                    }
                }
                System.out.println("Records Sorted By CGPA");
            } catch (IndexOutOfBoundsException e) {
                System.out.println("Error during sorting: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }

        //selection sort for id
        void sortbyID() {
            int n = student.size();

            for (int i = 0; i < n - 1; i++) {
                int minIndex = i;
                for (int j = i + 1; j < n; j++) {
                    if (student.get(j).getStdID() < student.get(minIndex).getStdID()) {
                        minIndex = j;
                    }
                }

                if (minIndex != i) {
                    Student temp = student.get(i);
                    student.set(i, student.get(minIndex));
                    student.set(minIndex, temp);
                }
            }

        }

        Student findStudent(int id){
            for (Student s : student){
                if (s.stdID == id){
                    return s;
                }
            }
            return null;
        }

        void markAttendence(int stdid, int courseid, STATUS s){
            try {
                Student student1 = findStudent(stdid);
                if (student1 == null){
                    System.out.println("student not in data :( ");
                    return;
                }

                ArrayList<Course> courses = student1.getCourses();
                Course c = null;

                for (Course co : courses){
                    if (co.getCourseid() == courseid){
                        c = co;
                        break;
                    }
                }

                if (c == null){
                    System.out.println("Course Not Found");
                    return;
                }

                c.attendence.pushAttendence(stdid, s);
                System.out.println("Attendence Added Succcesfully :)");

            } catch (Exception e) {
                System.out.println("Error while marking attendance");
            }
        }

    void undoAttendence(int stdid,int courseid){
        try {
            Student student1 = findStudent(stdid);
            if (student1 == null){
                System.out.println("student not in data :( ");
                return;
            }

            ArrayList<Course> courses = student1.getCourses();
            Course c = null;

            for (Course co : courses){
                if (co.getCourseid() == courseid){
                    c = co;
                    break;
                }
            }

            if (c == null){
                System.out.println("Course Not Found");
                return;
            }

            int rnum = c.attendence.popAttendence();
            if (rnum != 1){
                System.out.println("Attendence For " + rnum + " Removed");
            } else {
                System.out.println("No Attendence Record ");
            }

        } catch (Exception e) {
            System.out.println("Error undoing attendance");
        }
    }


    void studentAttendence(int id,int cid){
        try {
            Student student1 = findStudent(id);
            if (student1 == null){
                System.out.println("student not in data :( ");
                return;
            }
            ArrayList<Course> courses = student1.getCourses();
            Course c = null;

            for (Course co : courses){
                if (co.getCourseid() == cid){
                    c = co;
                    break;
                }
            }
            if (c == null){
                System.out.println("Course Not Found");
                return;
            }
            c.attendence.PrintAttendence();
        } catch (Exception e) {
            System.out.println("Error displaying attendance");
        }
    }


    double attendencepercent(int stdid, int courseid) {
        Student std2 = findStudent(stdid);
        if (std2 == null) {
            System.out.println("Student not in data :( ");
            return 0.0;
        }

        ArrayList<Course> courses = std2.getCourses();
        Course c = null;
        for (Course co : courses) {
            if (co.getCourseid() == courseid) {   // use getter if preferred
                c = co;
                break;
            }
        }

        if (c == null) {
            System.out.println("Course Not Found");
            return 0.0;
        }

        if (c.getAttendence() == null) {
            System.out.println("No attendance record for this course");
            return 0.0;
        }

        int present = c.getAttendence().countpresent();
        int total = c.getAttendence().countclasses();

        if (total == 0) {
            System.out.println("0% As no class have been Conducted");
            return 0.0;
        }
        double percentage = (present * 100.0) / total;
        return percentage;
    }

    //searching by binary search
    void searchstdByid(int id) {
        sortbyID(); // make sure the list is sorted
        int lb = 0;
        int ub = student.size() - 1;

        while (lb <= ub) {
            int mid = (lb + ub) / 2;
            int midId = student.get(mid).getStdID();

            if (midId == id) {
                System.out.println(student.get(mid).displayrecord());
                return;
            } else if (midId < id) {
                lb = mid + 1;
            } else {
                ub = mid - 1;
            }
        }
        System.out.println("Student not found");
    }

    // FILING METHODS FROM HERE :(

    void saveStudents() {
        try (PrintWriter writer = new PrintWriter("students.txt")) {
            System.out.println("            ID           Name           Age           CGPA");
            for (Student s : student) {
                writer.println("           "+s.getStdID() + "           "+ s.getName() + "           "+ s.getAge() + "           "+ s.getCgpa());
            }
            System.out.println("Students saved successfully.");
        } catch (Exception e) {
            System.out.println("Error saving students: " + e.getMessage());
        }
    }

    void saveCourses() {
        try (PrintWriter writer = new PrintWriter("courses.txt")) {
            System.out.println("           "+"ID"+"           "+"Name");
            for (AllCourses c : allcourses) {
                writer.println(c.getCourseid() + "           "+ c.getCourseName());
            }
            System.out.println("Courses saved successfully.");
        } catch (Exception e) {
            System.out.println("Error saving courses: " + e.getMessage());
        }
    }

    void saveStudentCourses() {
        try (PrintWriter writer = new PrintWriter("student_courses.txt")) {
            for (Student s : student) {
                writer.println("Student: "+s.getStdID());
                writer.println("           "+"ID"+"           "+"Course id"+"           "+"Course Name");
                for (Course c : s.getCourses()) {
                    writer.println("           "+s.getStdID() + "           "+ c.getCourseid() + "           "+ c.getCourseName());
                }
            }
            System.out.println("Student courses saved successfully.");
        } catch (Exception e) {
            System.out.println("Error saving student courses: " + e.getMessage());
        }
    }

    void saveAttendance() {
        try (PrintWriter writer = new PrintWriter("attendance.txt")) {
            for (Student s : student) {
                writer.println(s.getStdID()+" :");
                for (Course c : s.getCourses()) {
                    Linkedlist temp = c.getAttendence().head;
                    while (temp != null) {
                        writer.println(c.getCourseid() + "           "+ c.getCourseName() + "           "+ temp.getDate() + "           "+ temp.getStatus());
                        temp = temp.next;
                    }
                }
            }
            System.out.println("Attendance saved successfully.");
        } catch (Exception e) {
            System.out.println("Error saving attendance: " + e.getMessage());
        }
    }
}
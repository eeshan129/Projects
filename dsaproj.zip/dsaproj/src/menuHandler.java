public class menuHandler {


    void mainMenu(){
        System.out.println("------------MAIN MENU -------------");
        System.out.println("1: Manage Student");
        System.out.println("2: Manage course ");
        System.out.println("3: Manage Attendence");
        System.out.println("4: Reports");
        System.out.println("5: File Handling");
        System.out.println("6: Exit");
    }
    void attendence(){
        System.out.println("1. Present");
        System.out.println("2. Absent");
    }

    void studentMenu(){
        System.out.println("----- Student Management -----");
        System.out.println("1. Add Student");
        System.out.println("2. Remove Student");
        System.out.println("3: Add Course For Student ");
        System.out.println("4: Remove Course For Student ");
        System.out.println("5. View All Students");
        System.out.println("6. Search Student by ID");
        System.out.println("7. Back to Main Menu");
    }

    void courseMenu(){
        System.out.println("----- Course Management -----\n" +
                "\n" +
                "1. Add Course\n" +
                "2. Remove Course\n" +
                "3. View All Courses\n" +
                "4. Back to Main Menu\n");
    }

    void attendanceMenu(){
        System.out.println("----- Attendance Management -----\n" +
                "\n" +
                "1. Mark Attendance (Today)\n" +
                "2. Undo Last Attendance\n" +
                "3. View Student Attendance (Course-wise)\n" +
                "4. Back to Main Menu\n");
    }

    void reportMenu(){
        System.out.println("----- Reports -----\n" +
                "\n" +
                "1. Search Student By ID (Student + Course)\n" +
                "2. Search Student By Name\n" +
                "3. Sort Student By ID \n" +
                "4. Sort Student By CGPA\n" +
                "5. Attendance Percentage (Student + Course)\n" +
                "6: View All Student \n" +
                        "7. Back to Main Menu\n"
        );
    }
    void fileMenu() {
        System.out.println("------ File Management Menu ------");
        System.out.println("1. Save all students");
        System.out.println("2. Save all courses");
        System.out.println("3. Save student courses");
        System.out.println("4. Save attendance");
        System.out.print("Enter your choice: ");
    }


    void space(){
        System.out.println("\n\n\n");
    }
}

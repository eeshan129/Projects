public enum STATUS {
    present,absent;
}

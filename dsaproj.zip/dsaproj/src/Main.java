import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        menuHandler Menu = new menuHandler();
        studentManager Student = new studentManager();

        while (true) {
            try {
                Menu.mainMenu();
                int choice = input.nextInt();
                switch (choice) {
                    case 1:
                        Menu.studentMenu();
                        choice = input.nextInt();
                        switch (choice) {

                            case 1:
                                try {
                                    Student.addStudent();
                                } catch (Exception e) {
                                    System.out.println("Invalid input while adding student");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 2:
                                try {
                                    System.out.println("Enter Student ID To Remove : ");
                                    int id = input.nextInt();
                                    Student.removeStudent(id);
                                } catch (Exception e) {
                                    System.out.println("Invalid Student ID");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 3:
                                try {
                                    System.out.println("Enter student ID who's Course you want to add: ");
                                    int idd = input.nextInt();
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID: ");
                                    int courseID = input.nextInt();
                                    System.out.println("Enter Course name: ");
                                    String Cname = input.next();
                                    Student.addCourseforStudent(idd, courseID, Cname);
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 4:
                                try {
                                    System.out.println("Enter student ID who's Course you want to Remove : ");
                                    int idd = input.nextInt();
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID: ");
                                    int courseID = input.nextInt();
                                    Student.removeCourseforstd(idd, courseID);
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 5:
                                Student.viewAllstudent();
                                Menu.space();
                                break;

                            case 6:
                                try {
                                    System.out.println("Enter Student ID To Search : ");
                                    int id2 = input.nextInt();
                                    Student.searchstdByid(id2);
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 7:
                                Menu.space();
                                break;

                            default:
                                System.out.println("Invalid choice");
                        }
                        break;

                    case 2:
                        Menu.courseMenu();
                        choice = input.nextInt();
                        switch (choice) {

                            case 1:
                                try {
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID: ");
                                    int id = input.nextInt();
                                    System.out.println("Enter Course Name : ");
                                    String name = input.next();
                                    Student.addallCourse(id, name);
                                } catch (Exception e) {
                                    System.out.println("Invalid course input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 2:
                                try {
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID To Remove : ");
                                    int id = input.nextInt();
                                    Student.removeMainCourse(id);
                                } catch (Exception e) {
                                    System.out.println("Invalid Course ID");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 3:
                                Student.viewAllCourses();
                                Menu.space();
                                break;

                            case 4:
                                Menu.space();
                                break;

                            default:
                                System.out.println("Invalid choice");
                        }
                        break;
                    case 3:
                        Menu.attendanceMenu();
                        choice = input.nextInt();
                        switch (choice) {

                            case 1:
                                try {
                                    System.out.println("Enter Student ID: ");
                                    int id = input.nextInt();
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID : ");
                                    int Cid = input.nextInt();
                                    Menu.attendence();
                                    int ch = input.nextInt();

                                    if (ch == 1)
                                        Student.markAttendence(id, Cid, STATUS.present);
                                    else if (ch == 2)
                                        Student.markAttendence(id, Cid, STATUS.absent);
                                    else
                                        System.out.println("Invalid status choice");
                                } catch (Exception e) {
                                    System.out.println("Invalid attendance input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 2:
                                try {
                                    System.out.println("Enter Student ID: ");
                                    int id = input.nextInt();
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID : ");
                                    int Cid = input.nextInt();
                                    Student.undoAttendence(id, Cid);
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 3:
                                try {
                                    System.out.println("Enter Student ID: ");
                                    int id = input.nextInt();
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID : ");
                                    int Cid = input.nextInt();
                                    Student.studentAttendence(id, Cid);
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 4:
                                Menu.space();
                                break;

                            default:
                                System.out.println("Invalid choice");
                        }
                        break;
                    case 4:
                        Menu.reportMenu();
                        choice = input.nextInt();
                        switch (choice) {

                            case 1:
                                try {
                                    System.out.println("Enter Student ID: ");
                                    int id = input.nextInt();
                                    Student.searchstdByid(id);
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;
                            case 2:
                                try {
                                    System.out.println("Enter Student name: ");
                                    String name = input.next();
                                    Student.searchstdByname(name);
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;

                            case 3:
                                Student.sortbyID();
                                System.out.println("Records Sorted By ID");
                                Menu.space();
                                break;
                            case 4:
                                Student.sortByCgpa();
                                Menu.space();
                                break;

                            case 5:
                                try {
                                    System.out.println("Enter Student ID: ");
                                    int id = input.nextInt();
                                    Student.viewAllCourses();
                                    System.out.println("Enter Course ID : ");
                                    int Cid = input.nextInt();
                                    double d = Student.attendencepercent(id, Cid);
                                    if (d != 0.0)
                                        System.out.println(String.format("%.2f %%", d));
                                } catch (Exception e) {
                                    System.out.println("Invalid input");
                                    input.nextLine();
                                }
                                Menu.space();
                                break;
                            case 6:
                                Student.viewAllstudent();
                                Menu.space();
                                break;
                            case 7:
                                Menu.space();
                                break;

                            default:
                                System.out.println("Invalid choice");
                        }
                        break;
                    case 5:
                        Menu.fileMenu();
                        int fChoice = input.nextInt();
                        switch(fChoice) {
                            case 1:
                                Student.saveStudents();
                                break;
                            case 2:
                                Student.saveCourses();
                                break;
                            case 3:
                                Student.saveStudentCourses();
                                break;
                            case 4:
                                Student.saveAttendance();
                                break;
                            default:
                                System.out.println("Invalid choice");
                        }
                        Menu.space();
                        break;

                    case 6:
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice");
                        Menu.space();
                }

            } catch (Exception e) {
                System.out.println("Invalid input! Try again.");
                input.nextLine();
            }
        }
    }
}
